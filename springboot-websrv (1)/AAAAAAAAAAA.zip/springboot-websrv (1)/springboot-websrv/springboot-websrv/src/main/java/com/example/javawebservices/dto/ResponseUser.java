package com.example.javawebservices.dto;

public record ResponseUser(long id, String username) {
}
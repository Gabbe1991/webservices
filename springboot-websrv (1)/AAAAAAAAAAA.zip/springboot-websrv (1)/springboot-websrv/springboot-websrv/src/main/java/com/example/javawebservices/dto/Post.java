package com.example.javawebservices.dto;

public record Post(int userId, int id, String title, String body) {
}

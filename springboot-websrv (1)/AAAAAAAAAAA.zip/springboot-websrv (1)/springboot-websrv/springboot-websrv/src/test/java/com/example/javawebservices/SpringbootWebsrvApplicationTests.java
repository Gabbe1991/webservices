package com.example.javawebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebsrvApplicationTests {

	@Test
	void contextLoads() {
	}

}
